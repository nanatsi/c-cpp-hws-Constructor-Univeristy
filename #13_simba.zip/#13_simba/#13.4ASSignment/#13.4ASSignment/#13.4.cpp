//CH - 230 - A
//a13.p3.c
// Nana Tsignadze
//ntsignadze@jacobs-university.de

#include<iostream>
using namespace std;

class A
{
    int x;
public:
    void setX(int i) { x = i; }
    void print() { cout << x; }
};

class B : public A
{
public:
    B() { setX(10); }
};

class C : public A
{
public:
    C() { setX(20); }
};

class D : public B, public C {
};

int main()
{
    D d;
    d.B::print();
    // the statement d.B::print(); was corrected because 
    // the values of x were distinct for B and C 
    // (since both inherits separately from A) and the program
    // couldn't determine which value to print.
    //  The issue was resolved by specifying
    // that the print method is called for the B class.
    //  For instance, I used B::print() to clarify the intended class context.
  
    return 0;
}