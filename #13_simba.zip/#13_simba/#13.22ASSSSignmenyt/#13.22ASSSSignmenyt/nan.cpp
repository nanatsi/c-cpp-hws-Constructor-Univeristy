//CH - 230 - A
//a13.p2.c
// Nana Tsignadze
//ntsignadze@jacobs-university.de

#include <iostream>
#include <cmath>
#include "Complex.h"

using namespace std;
//default constructor
Complex::Complex() : real(0), imag(0) {}
//parameterized constructor
Complex::Complex(double a, double b) : real(a), imag(b) {}
//copy constructor
Complex::Complex(const Complex& k) : real(k.real), imag(k.imag) {}
//destructor
Complex::~Complex() {
    cout << "Executing destructor" << endl;
}

//setter and getter for real and imaginary part
void Complex::setReal(double a) {
    real = a;
}

void Complex::setImag(double b) {
    imag = b;
}

double Complex::getReal() const {
    return real;
}

double Complex::getImag() const {
    return imag;
}
//input stream operator to read
std::istream& operator>>(std::istream& in, Complex& C) {
    in >> C.real >> C.imag;

    return in;
}
//output stream operator to print
std::ostream& operator<<(std::ostream& out, const Complex& C) {
    if (C.imag < 0) {
        out << C.real << " " << C.imag << "i" << endl;

    }
    else {
        out << C.real << " + " << C.imag << "i" << endl;
    }
    return out;
}
//for overloading operators
Complex Complex::operator+(const Complex& C) const {
    return Complex(C.real + real, C.imag + imag);
}

Complex Complex::operator-(const Complex& C) const {
    return Complex(real - C.real, imag - C.imag);
}
Complex Complex::operator*(const Complex& C) const {
    return Complex(C.real * real - imag * C.imag, 
        C.real * imag + C.imag * real);
}

Complex& Complex::operator=(const Complex& C) {
    if (this != &C) {

        this->real = C.real;
        this->imag = C.imag;
    }
    return *this;
}
