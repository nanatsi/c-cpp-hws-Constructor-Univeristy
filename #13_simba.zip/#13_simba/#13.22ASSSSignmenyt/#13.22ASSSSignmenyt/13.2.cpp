//CH - 230 - A
//a13.p2.c
// Nana Tsignadze
//ntsignadze@jacobs-university.de

#include<iostream>
#include <fstream>
#include "Complex.h"

using namespace std;

int main() {

    Complex c1, c2;

    //opening files
    ifstream f_1("in1.txt");

    if (!f_1.good()) {
        cerr << "error occured while opening in1.txt." << endl;
        exit(1);
    }

    ifstream f_2("in2.txt");

    if (!f_2.good()) {
        cerr << "error occured while opening in2.txt." << endl;
        exit(1);
    }

    //reading complex numbers
    if (f_1 >> c1) {}

    else {
        cerr << "error occured while reading complex number1" << endl;
        return 1;
    }

    if (f_2 >> c2) {}

    else {
        cerr << "error occured while reading complex number2" << endl;
        return 1;
    }
    

    f_1.close();
    f_2.close();
    


    Complex sum, diff, prod;

    //computing sum, difference and product
    sum = c1 + c2;
    diff = c2 - c1;
    prod = c1 * c2;

    //writing everything in output file
    ofstream output("output.txt");

    if (!output.is_open()) {
        cerr << "error occurred while opening output.txt." << endl;
        exit(1);
    }

    output << "Sum: " << sum << endl;
    output << "Difference: " << diff << endl;
    output << "Product: " << prod << endl;
   

    output.close();

    //shows on the screen to check overloading <<, >> operators
    cout << "the sum: " << sum << endl;
    cout << "the difference: " << diff << endl;
    cout << "the product: " << prod << endl;
    


    return 0;
}