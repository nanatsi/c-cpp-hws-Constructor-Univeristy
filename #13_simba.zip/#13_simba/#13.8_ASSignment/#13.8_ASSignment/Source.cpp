//CH - 230 - A
//a13.p8.cpp
// Nana Tsignadze
//ntsignadze@jacobs-university.de

#include <iostream>

using namespace std;

//motor class definition
class Motor {
public:
    
    Motor() {
        //throws exception with an error message
        throw string("This motor has problems");
    }
};
//car class definition
class Car {
private:
    Motor m;  
public:
    //default constructor
    Car() {}
};

//garage class definition
class Garage {
public:
    
    Garage() {
        try {
            //creates a car object inside the class
            createCar();
        }
        catch (const string& motorException) {
            //if an exception is cought throws a new one with error message
            throw string("The car in this garage has problems with the motor");
        }
    }
    //function to create car object
    void createCar() {
        try {
            Car c;
        }
        //rethrow an exception if cought
        catch (const string& motorException) {
            throw;
        }
    }
};


int main() {
    try {
        //creating a garage object
        Garage g;
    }
    catch (const string& e) {
        //shows an error message
        cerr << e << endl;
    }

    return 0;
}
