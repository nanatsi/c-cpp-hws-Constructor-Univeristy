//CH - 230 - A
//a13.p3.c
// Nana Tsignadze
//ntsignadze@jacobs-university.de
#include <iostream>
#include <fstream>
#include <string>

int main() {
    //reading the number of files
    int num;
    std::cin >> num;

    //opens output file
    std::ofstream out("concatn.txt");
    if (!out.good()) {
        std::cerr << "error occurred while opening!" << std::endl;
        exit(1);
    } 
    //reads n file names
    for (int i = 0; i < num; i++) {
        std::string inputName;
        std::cin >> inputName;
        std::ifstream in(inputName);
        if (!in.good()) {
            std::cerr << "error occurred while opening!" << std::endl;
            exit(1);
        }
        //reads line by line and 
        //writes into output line
        std::string line;
        while (std::getline(in, line)) {
            out << line << std::endl;
        }
        out << "\n";
        //closes input files
        in.close(); 
    }
    //closes output file
    out.close(); 
    return 0;
}

