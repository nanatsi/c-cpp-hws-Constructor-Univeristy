#include<iostream>
#include <fstream>
#include "Complex.h"

using namespace std;

int main() {
    ifstream f1("in1.txt");
    ifstream f2("in2.txt");

    Complex a, b;

    if (!f1.good()) {
        cerr << "Error opening the in1.txt." << endl;
        exit(1);
    }
    //checker for opening

    if (!f2.good()) {
        cerr << "Error opening the in2.txt." << endl;
        exit(1);
    }
    //checker for opening


    if (f1 >> a) {}

    else {
        cerr << "Error reading complex number from in1.txt" << endl;
        return 1;
    }
    //checking if number was read from in1.txt

    if (f2 >> b) {}
    else {
        cerr << "Error reading complex number from in2.txt" << endl;
        return 1;
    }
    //checking if number was read from in2.txt

    f1.close();
    f2.close();
    //closing files

    Complex sum, diff, prod;

    sum = a + b;
    diff = a - b;
    prod = a * b;
    //doing operations with overloaded operators

    cout << "Sum: " << sum << endl;
    cout << "Difference: " << diff << endl;
    cout << "Product: " << prod << endl;
    //using overloaded <<


    ofstream output("output.txt");

    output << "Sum: " << sum << endl;
    output << "Difference: " << diff << endl;
    output << "Product: " << prod << endl;
    //writing in output file

    output.close();
    //closing output file

    return 0;
}