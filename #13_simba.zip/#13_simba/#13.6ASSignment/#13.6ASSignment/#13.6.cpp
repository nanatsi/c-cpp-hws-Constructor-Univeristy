//CH - 230 - A
//a13.p6.cpp
// Nana Tsignadze
//ntsignadze@jacobs-university.de
#include <iostream>
#include <vector>

int main() {
	//adding value 8 20 times
	std::vector<int> Vector(20, 8); 
	try {
		//trying to access the 21st element
		Vector.at(21);
	}
	catch (std::out_of_range const& v) {
		//printing the error
		std::cerr << v.what(); 
	}
	return 0;
}