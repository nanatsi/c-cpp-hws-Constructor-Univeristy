#include <iostream>
//CH - 230 - A
//a13.p7.cpp
// Nana Tsignadze
//ntsignadze@jacobs-university.de


//creates class of exception
class OwnException { 
public:
    std::string exception;
    OwnException(const std::string& exc) { exception = exc; }
    const char* what() const noexcept {
        return "OwnException\n";
    }
};

void exceptions(int n) {
    //throws exceptions for different types
    switch (n) { 
    case 1:
        throw 'a';
        break;
    case 2:
        throw 12;
        break;
    case 3:
        throw true;
        break;
    default:
        throw OwnException("default case exception");
        break;
    }
}
int main() {
    //calling the function and testing for each exception
    try {
        exceptions(1);
    }

    catch (char ch) {
        std::cerr << "Caught in main: " << ch << std::endl;
    }

    try {
        exceptions(2);
    }

    catch (int n) {
        std::cerr << "Caught in main: " << n << std::endl;
    }

    try {
        exceptions(3);
    }

    catch (bool val) {
        std::cerr << "Caught in main: " << val << std::endl;
    }

    try {
        exceptions(4);
    }

    catch (OwnException a) {
        std::cerr << "Caught in main: " << a.what() << std::endl;
    }
    return 0;
}