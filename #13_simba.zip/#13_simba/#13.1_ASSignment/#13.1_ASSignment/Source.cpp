//CH - 230 - A
//a13.p1.cpp
// Nana Tsignadze
//ntsignadze@jacobs-university.de
#include <iostream>
#include <fstream>
#include <string>
int main() {

	std::string inputName;
	std::cin >> inputName;

	//opening the input file
	std::ifstream in(inputName);
	//checking
	if (!in.good()) {
		std::cerr << "Error occured while opening " << std::endl;
		exit(1);
	}

	std::string outputName;
	std::string outputExtension;

	//finding position of dot
	int i = inputName.find('.');
	outputName = inputName.substr(0, i);
	outputExtension = inputName.substr(i);

	//creating the output file name 
	//adding "_copy" to the original name
	std::string outputFile = outputName + "_copy" + outputExtension;

	//oppening output file
	std::ofstream out(outputFile);
	if (!out.good()) {
		std::cerr << "Error occured while opening!" << std::endl;
		exit(2);
	}

	//reading an then writing the text line by line 
	//into the output file
	std::string line;
	while (getline(in, line)) {
		out << line << std::endl;
	}

	//closing both
	in.close();
	out.close();

	return 0;
}