//CH - 230 - A
//a13.p5.cpp
// Nana Tsignadze
//ntsignadze@jacobs-university.de
#include<iostream>
using namespace std;

class A
{
    int x;
public:

    //The addition of a default constructor to class A was necessary 
    //to enable the creation of an instance of class D
    //without default constructor compiler would not
    //be able to generate the default case 

    A() { x = 10; }
    A(int i) { x = i; }
    void print() { cout << x; }
};

class B : virtual public A
{
public:
    B() : A(10) {  }
};

class C : virtual public A
{
public:
    C() : A(10) {  }
};

class D : public B, public C {
};

int main()
{
    D d;
    d.print();
    return 0;
}