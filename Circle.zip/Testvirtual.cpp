//CH - 230 - A
//a12.p6.c
// Nana Tsignadze
//ntsignadze@jacobs-university.de



/*


		  +---------+
		  |  area   |
		  +---------+
			  |
			  |
   +----------|-------------+					
   |             			|		 					
+--+--+   				 +--+---+			
|circle|   				 | rect |	   
+--+--+  				 +--+--++   
	|	     			____|____    	
+---+---+ 	   		   | square | 			  
/  ring /              +--------+   
+---+---+          
       
	   				
	   

*/

#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"

const int num_obj = 7;
int main() {
	// (1) - creating an array of pointers to the Area class to 
	//hold objects of derived classes.
	Area* list[num_obj];
	// (2) - assigning an index variable prime 
	// value to 0 in order to iterate 
	// through the array of objects
	int index = 0;	
	// (3) - initializing variables to calculate the total 
	// area and perimeter of all objects.
	double sum_area = 0.0;
	double sum_per = 0.0;
	cout << "Creating Ring: ";
	// (4) - creating 6 different objects of 
	// varius geometric
	//  data using their constructors.
	Ring blue_ring("BLUE", 5, 2);				
	cout << "Creating Circle: ";
	Circle yellow_circle("YELLOW", 7);
	cout << "Creating Rectangle: ";
	Rectangle green_rectangle("GREEN", 5, 6);
	cout << "Creating Circle: ";
	Circle red_circle("RED", 8);
	cout << "Creating Rectangle: ";
	Rectangle black_rectangle("BLACK", 10, 20);
	cout << "Creating Ring: ";
	Ring violet_ring("VIOLET", 100, 5);
	cout << "Creating Square: ";
	Square Pink_square("PINK", 11);
	// (5) - asigning objects to
	//  the array of pointers.
	list[0] = &blue_ring;						
	list[1] = &yellow_circle;
	list[2] = &green_rectangle;
	list[3] = &red_circle;
	list[4] = &black_rectangle;
	list[5] = &violet_ring;
	list[6] = &Pink_square;
	// (7) - iterating through the array of
	//  objects and calculating area.
	while (index < num_obj) {					
		(list[index])->getColor();
		// 8() - creating double area which hods
		// the calculated area and while iterating
		// each time the index is modified 
		// calcarea() method invokes for the compatable object
		double area = list[index]->calcArea();
		double perimeter = list[index]->calcPerimeter();
		sum_area += area;
		sum_per += perimeter;
		index++;

	}
	// (9) - printing the total area and total
	//  perimeter of all objects
	cout << "\nThe total area is "
		<< sum_area << " units " << endl;
	cout << "\nthe total perimeter is "
		<< sum_per << " units " << endl;
	return 0;
}
