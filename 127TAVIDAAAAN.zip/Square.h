//CH - 230 - A
//a12.p6.c
// Nana Tsignadze
//ntsignadze@jacobs-university.de
#ifndef _SQUARE_H
#define _SQUARE_H
#include "Rectangle.h"
//creatin square class derived from Rectangle
class Square : public Rectangle {
public:
    //normal constructor
    Square(const char* n, double side);
    //destructor
    ~Square();
    //
    double calcArea() const;
    double calcPerimeter() const;
private:
    double side;
};

#endif
