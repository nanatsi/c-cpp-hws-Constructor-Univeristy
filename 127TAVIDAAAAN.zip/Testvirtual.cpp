//CH - 230 - A
//a12.p7.c
// Nana Tsignadze
//ntsignadze@jacobs-university.de


/*


          +---------+
          |  area   |
          +---------+
              |
              |
   +----------|-------------+
   |             			|
+--+--+   				 +--+---+
|circle|   				 | rect |
+--+--+  				 +--+--++
    |	     			____|____
+---+---+ 	   		   | square |
/  ring /              +--------+
+---+---+




*/

#include <iostream>
#include <cstdlib>  
#include <ctime>    
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"

//our object number now is 25
const int num_obj = 25;

int main() {
    //makes sure that each time the randomly chosen things 
    //are different
    std::srand(static_cast<unsigned int>(std::time(0)));


    double sum_area = 0.0;
    double sum_per = 0.0;
    Area* list[num_obj];
    const char* colors[] = { "RED", "BLACK", "VIOLET", "BLUE" };

    int count = 0;

    while (count < num_obj) {

        int shape = rand() % 4;
        //sets sizes from 5 to 100
        double rsize_1 = 1.0;
        double rsize_2 = 2.0;
        while(true) {
            rsize_1 = (rand() % 96) + 5;
            rsize_2 = (rand() % 96) + 5;
            if (rsize_1 > rsize_2) {
                break;
            }
        }
        //sets color using rand
        const char* color = colors[rand() % 4];
        // 4 shapes in total (create switch statement)
        switch (shape) {
        case 0:
            std::cout << "\ncircle is being called..." << std::endl;
            list[count] = new Circle(color, rsize_1);
            break;
        case 1:
            std::cout << "\nring is being called..." << std::endl;
            list[count] = new Ring(color, rsize_1, rsize_2);
            break;
        case 2:
            std::cout << "\nrectangle is being called..." << std::endl;
            list[count] = new Rectangle(color, rsize_1, rsize_2);
            break;
        case 3:
            std::cout << "\nsquare is being called..." << std::endl;
            list[count] = new Square(color, rsize_1);
            break;
        }
        //computing area and perimeter of each
        //and increasing the total compatably
        double area = list[count]->calcArea();
        double perimeter = list[count]->calcPerimeter();
        sum_area += area;
        sum_per += perimeter;

        std::cout << "\n\nthe area of figure N" << count+1
            << " is :" << area;
        std::cout << "\nthe perimeter of figure N" << count+1
            << " is: " << perimeter << std::endl;
        count++;
    }

    // (9) - printing the total area and total
     //  perimeter of all objects
    std::cout << "\nThe total area is "
        << sum_area << " units ";
    std::cout << "\nthe total perimeter is "
        << sum_per << " units " << std::endl;
    return 0;

    //deallocation
    for (int i = 0; i < num_obj; i++) {
        delete list[i];
    }

    return 0;
}






