//CH - 230 - A
//a12.p6.c
// Nana Tsignadze
//ntsignadze@jacobs-university.de
#include <iostream>
#include <cmath>
#include "Circle.h"

Circle::Circle(const char* n, double a) : Area(n) {
	radius = a;
}

Circle::~Circle() {
}

double Circle::calcArea() const {
	std::cout << "calcArea of Circle...";
	return radius * radius * 3.14;
}
double Circle::calcPerimeter() const {
	std::cout << "calcperimeter of Circle...";
	return radius * 2 * 3.14;
}